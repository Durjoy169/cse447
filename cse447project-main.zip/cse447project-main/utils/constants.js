export const Domain = process.env.NEXT_PUBLIC_Domain;
